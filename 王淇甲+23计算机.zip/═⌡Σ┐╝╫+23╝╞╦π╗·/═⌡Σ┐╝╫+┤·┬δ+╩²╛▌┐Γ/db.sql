﻿/*
SQLyog Community Edition- MySQL GUI v6.54
MySQL - 5.5.25a : Database - jspmsysqdxtnsb4mysql
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`jspmsysqdxtnsb4mysql` /*!40100 DEFAULT CHARACTER SET gb2312 */;

USE `jspmsysqdxtnsb4mysql`;

-- ----------------------------
-- Table structure for `allusers`
-- ----------------------------
DROP TABLE IF EXISTS `allusers`;
CREATE TABLE `allusers` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `pwd` varchar(50) DEFAULT NULL,
  `cx` varchar(50) DEFAULT NULL,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of allusers
-- ----------------------------
INSERT INTO `allusers` VALUES ('1', 'hsg', 'hsg', '超级管理员', '2018-05-30 23:45:04');
INSERT INTO `allusers` VALUES ('2', 'admin', 'admin', '超级管理员', '2018-05-30 23:45:04');

-- ----------------------------
-- Table structure for `chuqintongji`
-- ----------------------------
DROP TABLE IF EXISTS `chuqintongji`;
CREATE TABLE `chuqintongji` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `xuehao` varchar(50) DEFAULT NULL,
  `xingming` varchar(50) DEFAULT NULL,
  `banji` varchar(50) DEFAULT NULL,
  `kechengmingcheng` varchar(50) DEFAULT NULL,
  `shangkeshijian` varchar(50) DEFAULT NULL,
  `xiakeshijian` varchar(50) DEFAULT NULL,
  `renkelaoshi` varchar(50) DEFAULT NULL,
  `shiyanshi` varchar(50) DEFAULT NULL,
  `fenqu` varchar(50) DEFAULT NULL,
  `zhujibianhao` varchar(50) DEFAULT NULL,
  `ipdizhi` varchar(50) DEFAULT NULL,
  `xiajishijian` varchar(50) DEFAULT NULL,
  `zhuangtai` varchar(50) DEFAULT NULL,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of chuqintongji
-- ----------------------------
INSERT INTO `chuqintongji` VALUES ('1', '001', '学生', '三班', '操作系统', '2018-06-02 09:30:27', '2018-06-01 19:44:26', '教师AA', '实验室1', 'A区', 'A78', '123456', '', '正常                        ', '2018-06-02 20:50:38');
INSERT INTO `chuqintongji` VALUES ('2', '001', '学生', '三班', '操作系统', '2018-06-02 09:30:27', '2018-06-01 19:44:26', '教师AA', '实验室1', 'A区', '123', '456', '', '迟到                        ', '2018-06-02 20:51:40');
INSERT INTO `chuqintongji` VALUES ('3', '001', '学生', '三班', '操作系统', '2018-07-10 20:58:17', '2018-07-17 20:58:23', '教师AA', '实验室2', 'B区', 'A78', '123456', '', '正常                        ', '2018-06-02 21:00:12');
INSERT INTO `chuqintongji` VALUES ('4', '001', '学生', '三班', '操作系统', '2018-06-02 09:30:27', '2018-06-01 19:44:26', '教师AA', '实验室1', 'A区', 'A78', '123456', '', '迟到                        ', '2018-06-02 21:00:30');

-- ----------------------------
-- Table structure for `jiaoshiqiandao`
-- ----------------------------
DROP TABLE IF EXISTS `jiaoshiqiandao`;
CREATE TABLE `jiaoshiqiandao` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `kechengmingcheng` varchar(50) DEFAULT NULL,
  `shiyanshi` varchar(50) DEFAULT NULL,
  `fenqu` varchar(50) DEFAULT NULL,
  `shangkeshijian` varchar(50) DEFAULT NULL,
  `renkelaoshi` varchar(50) DEFAULT NULL,
  `banji` varchar(50) DEFAULT NULL,
  `qiandaoren` varchar(50) DEFAULT NULL,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of jiaoshiqiandao
-- ----------------------------
INSERT INTO `jiaoshiqiandao` VALUES ('4', '操作系统', '实验室2', 'C区', '2018-06-02 03:00:07', '教师AA', '三班', '001', '2018-06-02 09:34:23');
INSERT INTO `jiaoshiqiandao` VALUES ('5', '操作系统', '实验室2', 'B区', '2018-07-10 20:58:17', '教师AA', '三班', '001', '2018-06-02 20:59:16');
INSERT INTO `jiaoshiqiandao` VALUES ('3', '操作系统', '实验室1', 'A区', '2018-06-01 19:44:24', '教师AA', '三班', '001', '2018-06-02 02:33:49');

-- ----------------------------
-- Table structure for `jiaoshixinxi`
-- ----------------------------
DROP TABLE IF EXISTS `jiaoshixinxi`;
CREATE TABLE `jiaoshixinxi` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `jiaoshihao` varchar(50) DEFAULT NULL,
  `mima` varchar(50) DEFAULT NULL,
  `xingming` varchar(50) DEFAULT NULL,
  `xingbie` varchar(50) DEFAULT NULL,
  `nianling` varchar(50) DEFAULT NULL,
  `zhicheng` varchar(50) DEFAULT NULL,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of jiaoshixinxi
-- ----------------------------
INSERT INTO `jiaoshixinxi` VALUES ('1', '001', '001', '教师AA', '男', '50', 'AAAA', '2018-05-31 02:26:21');

-- ----------------------------
-- Table structure for `kebiaoxinxi`
-- ----------------------------
DROP TABLE IF EXISTS `kebiaoxinxi`;
CREATE TABLE `kebiaoxinxi` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `kechengmingcheng` varchar(50) DEFAULT NULL,
  `kechengkeshi` varchar(50) DEFAULT NULL,
  `shiyanshi` varchar(50) DEFAULT NULL,
  `fenqu` varchar(50) DEFAULT NULL,
  `shangkeshijian` varchar(50) DEFAULT NULL,
  `xiakeshijian` varchar(50) DEFAULT NULL,
  `renkelaoshi` varchar(50) DEFAULT NULL,
  `banji` varchar(50) DEFAULT NULL,
  `beizhu` varchar(50) DEFAULT NULL,
  `issh` varchar(2) DEFAULT NULL,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kebiaoxinxi
-- ----------------------------
INSERT INTO `kebiaoxinxi` VALUES ('1', '操作系统', '40', '实验室1', 'A区', '2018-06-02 09:30:27', '2018-06-01 19:44:26', '教师AA', '三班', '', '是', '2018-06-01 19:44:41');
INSERT INTO `kebiaoxinxi` VALUES ('2', '操作系统', '40', '实验室2', 'C区', '2018-06-03 09:30:27', '2018-06-02 04:00:20', '教师AA', '三班', '', '否', '2018-06-02 03:00:44');
INSERT INTO `kebiaoxinxi` VALUES ('3', '大时代', '40', '实验室2', 'B区', '2018-06-02 09:30:27', '2018-06-03 09:30:30', '教师AA', '三班', '', '否', '2018-06-02 09:30:46');
INSERT INTO `kebiaoxinxi` VALUES ('4', '大时代', '40', '实验室3', 'D区', '2018-06-02 20:57:27', '2018-06-13 20:57:34', '教师AA', '三班', '', '否', '2018-06-02 20:57:48');
INSERT INTO `kebiaoxinxi` VALUES ('5', '操作系统', '40', '实验室2', 'B区', '2018-07-10 20:58:17', '2018-07-17 20:58:23', '教师AA', '三班', '', '是', '2018-06-02 20:58:33');

-- ----------------------------
-- Table structure for `kechengxinxi`
-- ----------------------------
DROP TABLE IF EXISTS `kechengxinxi`;
CREATE TABLE `kechengxinxi` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `kechengbianhao` varchar(50) DEFAULT NULL,
  `kechengmingcheng` varchar(50) DEFAULT NULL,
  `kechengkeshi` varchar(50) DEFAULT NULL,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kechengxinxi
-- ----------------------------
INSERT INTO `kechengxinxi` VALUES ('1', '001', '操作系统', '40', '2018-06-01 06:48:55');
INSERT INTO `kechengxinxi` VALUES ('2', '123456', '大时代', '40', '2018-06-02 09:29:52');

-- ----------------------------
-- Table structure for `shiyanshigonggao`
-- ----------------------------
DROP TABLE IF EXISTS `shiyanshigonggao`;
CREATE TABLE `shiyanshigonggao` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `biaoti` varchar(50) DEFAULT NULL,
  `neirong` varchar(255) DEFAULT NULL,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of shiyanshigonggao
-- ----------------------------
INSERT INTO `shiyanshigonggao` VALUES ('1', '111', '11111111111', '2018-05-31 02:15:43');
INSERT INTO `shiyanshigonggao` VALUES ('2', '阿莎是的阿萨德阿萨德收到', '123123123123123123', '2018-05-31 02:24:42');
INSERT INTO `shiyanshigonggao` VALUES ('3', '45656', 'asdasdasdasd', '2018-06-02 09:29:07');

-- ----------------------------
-- Table structure for `xueshengxinxi`
-- ----------------------------
DROP TABLE IF EXISTS `xueshengxinxi`;
CREATE TABLE `xueshengxinxi` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `xuehao` varchar(50) DEFAULT NULL,
  `mima` varchar(50) DEFAULT NULL,
  `xingming` varchar(50) DEFAULT NULL,
  `xingbie` varchar(50) DEFAULT NULL,
  `nianling` varchar(50) DEFAULT NULL,
  `banji` varchar(50) DEFAULT NULL,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xueshengxinxi
-- ----------------------------
INSERT INTO `xueshengxinxi` VALUES ('1', '001', '001', '学生', '男', '50', '三班', '2018-06-02 02:36:54');

-- ----------------------------
-- Table structure for `zhujixinxi`
-- ----------------------------
DROP TABLE IF EXISTS `zhujixinxi`;
CREATE TABLE `zhujixinxi` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `shiyanshi` varchar(50) DEFAULT NULL,
  `fenqu` varchar(50) DEFAULT NULL,
  `zhujibianhao` varchar(50) DEFAULT NULL,
  `ipdizhi` varchar(50) DEFAULT NULL,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of zhujixinxi
-- ----------------------------
INSERT INTO `zhujixinxi` VALUES ('1', '实验室1', 'A区', '1', '123456', '2018-06-01 06:49:51');
INSERT INTO `zhujixinxi` VALUES ('2', '实验室1', 'A区', '123', '456', '2018-06-01 06:50:01');
INSERT INTO `zhujixinxi` VALUES ('3', '实验室1', 'A区', 'A78', '123456', '2018-06-02 09:30:12');

